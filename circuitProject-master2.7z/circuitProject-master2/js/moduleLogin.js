<!-- script pour module login -->
			$(document).ready(function(){
				$("#myBtn1").click(function(){
					$("#login-modal").modal();
				});
			});

			
			
			
			
			
		$(document).ready(function(){
    $(".col-sm-4.myBtn").click(function(){
        $("#myModal").modal();
    });
});